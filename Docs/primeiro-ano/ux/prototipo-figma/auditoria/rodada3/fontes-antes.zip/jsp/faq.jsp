<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Mottainai | Perguntas frequentes</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/prototipo-figma/css/faq.css" />
  <link rel="stylesheet" href="${pageContext.request.contextPath}/prototipo-figma/css/fontes.css">
<link rel="stylesheet" href="${pageContext.request.contextPath}/prototipo-figma/css/publico.css">
<link rel="shortcut icon" href="${pageContext.request.contextPath}/prototipo-figma/assets/img/favicon.ico" type="image/x-icon">
</head>
  <body>
    <header>
      <a href="${pageContext.request.contextPath}/home" class="logo">
        <img src="${pageContext.request.contextPath}/prototipo-figma/assets/img/home-logo.png" alt="Mottainai" />
      </a>

      <nav>
        <ul>
          <li><a href="${pageContext.request.contextPath}/home">Home</a></li>
          <li><a href="${pageContext.request.contextPath}/sobre-nos">Sobre nós</a></li>
          <li><a href="${pageContext.request.contextPath}/planos">Planos</a></li>
        </ul>
      </nav>

      <a href="${pageContext.request.contextPath}/home#contato" class="btn-contato botao-com-hover">Entre em contato</a>
    </header>
    <main class="faq-main">
      <section class="faq-hero">
        <p class="eyebrow">Bom demais para ser desperdiçado</p>
        <h1>Como podemos <em>ajudar?</em></h1>
        <p>Entenda a proposta da Mottainai e encontre respostas para começar.</p>
        <p class="nota-demonstracao">Proposta visual. Perguntas e respostas demonstrativas, sujeitas à validação da equipe.</p>
      </section>
      <section class="faq-lista" aria-label="Perguntas frequentes">
<details><summary>O que é a Mottainai?</summary><p>Uma proposta de plataforma para acompanhar estoques e apoiar a redução de desperdícios no varejo alimentar.</p></details>
<details><summary>Para quais tipos de mercado a plataforma foi criada?</summary><p>Esta demonstração considera mercados e redes de varejo. A adequação à operação deve ser avaliada com a equipe.</p></details>
<details><summary>Como funciona o controle de validade?</summary><p>O protótipo ilustra o acompanhamento de produtos e vencimentos. A forma de cadastro e as integrações serão confirmadas na implantação.</p></details>
<details><summary>Como funcionam os alertas?</summary><p>A proposta visual apresenta alertas para apoiar a priorização de ações. Canais, limites e regras dependem de definição do produto.</p></details>
<details><summary>Quantas lojas posso cadastrar?</summary><p>Os limites devem ser confirmados no plano contratado; este conteúdo não estabelece condições comerciais.</p></details>
<details><summary>Qual plano devo escolher?</summary><p>Compare as opções na página de Planos e avalie as necessidades da sua operação com a equipe.</p></details>
<details><summary>Posso alterar meu plano?</summary><p>As condições de mudança de plano devem ser combinadas com a equipe. Esta demonstração não executa alterações de assinatura.</p></details>
<details><summary>Como funciona o cadastro de funcionários?</summary><p>A área administrativa apresenta o vínculo entre lojas, funcionários e cargos. Os cadastros desta prévia são apenas exemplos visuais.</p></details>
<details><summary>Os dados são protegidos?</summary><p>O projeto atual possui mecanismos de proteção de dados. Esta FAQ demonstrativa não substitui documentação técnica, política de privacidade ou garantias contratuais.</p></details>
<details><summary>Como entrar em contato?</summary><p>O destino definitivo dos botões Entre em contato ainda será informado. Os links existentes foram mantidos sem criar uma integração nova.</p></details>
</section><section class="faq-rodape"><h2>Conheça os nossos planos</h2><p>Opções para diferentes momentos da sua operação.</p><a class="btn-contato botao-com-hover" href="${pageContext.request.contextPath}/planos">Ver planos</a></section></main><footer>
    <div class="footer-topo">
        <div class="footer-logo">
            <img src="${pageContext.request.contextPath}/prototipo-figma/assets/img/home-logo-rodape.png" alt="Mottainai" />
            <p>Bom demais para ser desperdiçado,</p>
        </div>

        <div class="footer-coluna">
            <h5>Página inicial</h5>
            <ul>
                <li>Diferencial</li>
                <li>Funcionalidades</li>
                <li>Sistema</li>
            </ul>
        </div>

        <div class="footer-coluna">
            <h5>Sobre nós</h5>
            <ul>
                <li>Nossa equipe</li>
                <li>Nosso propósito</li>
                <li>No que acreditamos</li>
            </ul>
        </div>

        <div class="footer-coluna">
            <h5>Planos</h5>
            <ul>
                <li>Condições</li>
                <li>Termos de Uso</li>
                <li>Contato</li>
            </ul>
        </div>

        <div class="footer-coluna">
            <h5>Nos siga nas Redes!</h5>
            <ul>
                <li>Instagram: @mottainai_app</li>
                <li>Tel Empresarial: (+55) 11 91234-5678</li>
                <li>Email: mottainai@gmail.com.br</li>
            </ul>
        </div>
    </div>

    <hr />
    <div class="footer-base">
        <p>
            &copy; 2026 Mottainai. Todos os direitos reservados. Gestão
            Preditiva de Perecíveis.
        </p>
    </div>
</footer>
</body></html>