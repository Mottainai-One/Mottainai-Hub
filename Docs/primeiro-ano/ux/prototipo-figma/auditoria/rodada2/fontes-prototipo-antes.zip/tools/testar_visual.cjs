// Ferramenta de revisão; Playwright vem do ambiente do Codex, não é dependência do projeto.
const fs=require('node:fs'), path=require('node:path'), assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const root=path.resolve(__dirname,'..');
const publicPages=['home','sobre-nos','planos','faq'];
const adminPages=['home-crud-page','companies','stores','employees','employee-roles','user-accounts','subscription-plans','addresses'];
const results={pages:[],interactions:{},errors:[],requests:[],metrics:{}};
const screenDir=path.join(root,'auditoria/capturas');fs.mkdirSync(screenDir,{recursive:true});
const uri=name=>pathToFileURL(path.join(root,'html',name+'.html')).href;

(async()=>{
 const browser=await chromium.launch({channel:'chrome',headless:true});
 try {
  const page=await browser.newPage();
  page.on('pageerror',e=>results.errors.push(String(e)));
  page.on('request',r=>{if(r.method()==='POST')results.requests.push(r.url());});
  for(const name of [...publicPages,...adminPages]) {
   const widths=publicPages.includes(name)?[1440,1024,768,390]:[1812,768,390];
   for(const width of widths){
    await page.setViewportSize({width,height:width===1812?963:1000});
    await page.goto(uri(name),{waitUntil:'load'});await page.evaluate(()=>document.fonts.ready);
    const status=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth+2,
     images:[...document.images].filter(i=>!i.complete||i.naturalWidth===0).map(i=>i.getAttribute('src')),
     fonts:[...document.fonts].map(f=>({family:f.family,status:f.status})),
     scripts:[...document.scripts].map(s=>s.getAttribute('src'))}));
    results.pages.push({name,width,...status});
    assert.equal(status.images.length,0,name+' / imagens ausentes');
    assert(!status.overflow,name+' / overflow destrutivo em '+width);
    if(publicPages.includes(name))await page.screenshot({path:path.join(screenDir,name+'-'+width+'.png'),fullPage:true});
    else if(width===1812||name==='companies')await page.screenshot({path:path.join(screenDir,name+'-'+width+'.png'),fullPage:true});
    if(width===1812){
     results.metrics[name]=await page.evaluate(()=>({sidebar:document.querySelector('.sidebar').getBoundingClientRect().width,
      header:document.querySelector('.header').getBoundingClientRect().height,
      title:getComputedStyle(document.querySelector('.pagina-titulo')).fontSize,
      row:document.querySelector('tbody tr')?.getBoundingClientRect().height,
      background:getComputedStyle(document.querySelector('.main')).backgroundColor}));
    }
   }
  }
  await page.setViewportSize({width:1440,height:1000});await page.goto(uri('home'));await page.evaluate(()=>document.fonts.ready);
  await page.locator('label.btn[for="login"]').click();assert(await page.locator('#login').isChecked());
  await page.screenshot({path:path.join(screenDir,'login-preservado.png')});
  await page.locator('#login-form input[name="email"]').fill('preview@example.test');
  await page.locator('#login-form input[name="password"]').fill('apenas-preview');
  const loginUrl=page.url();await page.locator('#login-form button').click();await page.waitForTimeout(100);
  assert.equal(page.url(),loginUrl);assert.equal(results.requests.length,0);
  await page.locator('#login-form label[for="cadastro"]').click();assert(await page.locator('#cadastro').isChecked());
  await page.screenshot({path:path.join(screenDir,'cadastro-preservado.png')});
  await page.keyboard.press('Escape');assert.equal(await page.locator('.modal:visible').count(),0);
  results.interactions.loginCadastro='alternância/fechamento preservados; HTML não autentica';
  await page.goto(uri('planos'));assert.equal(await page.locator('script[src]').count(),0);
  await page.locator('label[for="cobranca-anual"]').click();assert(await page.locator('#cobranca-anual').isChecked());
  assert(await page.getByText('R$ 10.000',{exact:true}).isVisible());assert(await page.getByText('R$ 28.000',{exact:true}).isVisible());
  await page.locator('#cobranca-anual').focus();await page.keyboard.press('ArrowLeft');assert(await page.locator('#cobranca-mensal').isChecked());
  assert(await page.getByText('R$ 1.200',{exact:true}).isVisible());results.interactions.planos='toggle nativo por clique/teclado; 0 JS';
  await page.goto(uri('faq'));assert.equal(await page.locator('script').count(),0);
  const summary=page.locator('summary').first();await summary.click();assert(await page.locator('details').first().evaluate(el=>el.open));
  await summary.focus();await page.keyboard.press('Enter');assert(!(await page.locator('details').first().evaluate(el=>el.open)));
  results.interactions.faq='details/summary nativo por clique/teclado; 0 JS';
  await page.goto(uri('sobre-nos'));assert.equal(await page.locator('script').count(),0);
  await page.locator('#significado label[for="hero-2"]').click();assert(await page.locator('#hero-2').isChecked());
  results.interactions.sobreNos='carrossel por radios/CSS; 0 JS';
  await page.setViewportSize({width:1812,height:963});
  for(const name of adminPages.filter(n=>n!=='home-crud-page')){
   await page.goto(uri(name));
   assert.equal(await page.locator('script[src$="crud.js"]').count(),1);
   assert(await page.locator('tbody tr').count()>=6);
   await page.locator('a[title="Editar"]').first().click();assert(await page.locator('.modal-overlay:target').isVisible());
   await page.screenshot({path:path.join(screenDir,name+'-editar.png')});
   const form=page.locator('.modal-overlay:target form').first();assert.equal(await form.getAttribute('method'),'dialog');
   await page.keyboard.press('Escape');assert.equal(await page.locator('.modal-overlay:target').count(),0);
  }
  await page.setViewportSize({width:390,height:844});await page.goto(uri('companies'));
  await page.locator('a[href*="#modal-empresa-criar"]').click();assert(await page.locator('#modal-empresa-criar').isVisible());
  const box=await page.locator('#modal-empresa-criar .modal').boundingBox();assert(box.width<=390);
  await page.locator('#modal-empresa-criar .modal').evaluate(el=>el.scrollTop=el.scrollHeight);
  await page.screenshot({path:path.join(screenDir,'companies-modal-390.png')});
  results.interactions.crud='7 modais de edição e modal mobile conferidos; formulários HTML inertes, sem fake CRUD';
  // Mesma estrutura/dados, apenas CSS V7 original para uma referência antes/depois mensurável.
  await page.setViewportSize({width:1812,height:963});
  
  await page.goto(uri('companies'));await page.locator('link[href$="crud.css" ]').evaluate((el,url)=>el.href=url,pathToFileURL(path.join(root,'../src/main/resources/static/assets/css/crud.css')).href);await page.waitForTimeout(300);await page.evaluate(()=>document.fonts.ready);
  results.metrics.baseV7=await page.evaluate(()=>({sidebar:document.querySelector('.sidebar').getBoundingClientRect().width,
   header:document.querySelector('.header').getBoundingClientRect().height,title:getComputedStyle(document.querySelector('.pagina-titulo')).fontSize,
   row:document.querySelector('tbody tr')?.getBoundingClientRect().height,background:getComputedStyle(document.querySelector('.main')).backgroundColor}));
  await page.screenshot({path:path.join(screenDir,'companies-estilo-v7.png'),fullPage:true});
  assert.equal(results.errors.length,0);assert.equal(results.requests.length,0);results.passed=true;
 } finally {await browser.close();fs.writeFileSync(path.join(root,'auditoria/visual.json'),JSON.stringify(results,null,2));}
 console.log(JSON.stringify({passed:results.passed,layouts:results.pages.length,errors:results.errors,posts:results.requests.length,metrics:results.metrics},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});

