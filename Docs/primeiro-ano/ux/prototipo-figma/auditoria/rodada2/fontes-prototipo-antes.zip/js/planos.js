// Protótipo: periodicidade e preços usam radios nativos e CSS. Nenhum script é carregado nesta página.
